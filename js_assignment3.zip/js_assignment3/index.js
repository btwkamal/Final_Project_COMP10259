function validateForm() {
    var firstname = document.getElementById('firstName').value;
    var lastName = document.getElementById('lastName').value;
    var email = document.getElementById('email').value;
    var date = document.getElementById('date').value;
    var phone = document.getElementById('phone').value;
    var message = document.getElementById('message').value;

    // Validate first name
    if (firstname< 5) {
        alert('First name should be at least 5 characters.');
        return false;
    }

    // Validate last name
    if (lastName.length < 5) {
        alert('Last name should be at least 5 characters.');
        return false;
    }

    // Validate email
    if (!email.includes('@')) {
        alert('Email should contain a valid domain name.');
        return false;
    }

    // Validate date
    var dateArray = date.split('/');
    if (dateArray.length !== 3 || dateArray[0].length !== 2 || dateArray[1].length !== 2 || dateArray[2].length !== 2) {
        alert('Date must have the appropriate format (dd/mm/yy).');
        return false;
    }

    // Validate phone
    if (phone.length !== 10) {
        alert('Phone must contain 10 digits.');
        return false;
    }

    // Validate message
    if (message.length < 50) {
        alert('Message must be at least 50 characters.');
        return false;
    }

    return true;
}
$(document).ready(function () {
    // Keep the navigation bar fixed
    $(window).scroll(function () {
        if ($(this).scrollTop() > 50) {
            $('header').addClass('fixed');
        } else {
            $('header').removeClass('fixed');
        }
    });
})
$(document).ready(function () {
    // Function to initialize the lightbox
    function initializeLightbox() {
        lightbox.option({
            'resizeDuration': 200,
            'wrapAround': true
        });
    }

    // Function to open the lightbox
    function openLightbox() {
        initializeLightbox();
        $('.lightbox').fadeIn();
    }

    // Function to close the lightbox
    function closeLightbox() {
        $('.lightbox').fadeOut();
    }

    // Open the lightbox when the form is submitted
    $('#contactForm').on('submit', function (e) {
        e.preventDefault();
        openLightbox();
    });

    // Close the lightbox when close button is clicked or anywhere outside the slideshow
    $(document).on('click', '.lb-close, .lightbox', function (e) {
        if ($(e.target).is('.lb-close') || $(e.target).is('.lightbox')) {
            closeLightbox();
        }
    });
});
